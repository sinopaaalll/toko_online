<?php
    $status = $_SESSION['status'];
    if($status != "login"){
        header('location:index.php?hal=home');
    }

    $id = $_REQUEST['id'];
    $objSuplai_barang = new Suplai_barang();
    $rs = $objSuplai_barang->getSuplai_barang($id); 
?>
<section class="section">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-body">
                    <table class="table table-hover mt-4">
                        <tr>
                            <td>Kode</td>
                            <td>:</td>
                            <td><?= $rs['kode'] ?></td>
                        </tr>
                        <tr>
                            <td>Tanggal</td>
                            <td>:</td>
                            <td><?= date('d M Y',strtotime($rs['tgl']))?></td>
                        </tr>
                        <tr>
                            <td>Supplier</td>
                            <td>:</td>
                            <td><?= $rs['supplier'] ?></td>
                        </tr>
                        <tr>
                            <td>Produk</td>
                            <td>:</td>
                            <td><?= $rs['produk'] ?></td>
                        </tr>
                        <tr>
                            <td>Jumlah</td>
                            <td>:</td>
                            <td><?= $rs['jumlah'] ?></td>
                        </tr>
                        <tr>
                            <td>Keterangan</td>
                            <td>:</td>
                            <td><?= $rs['keterangan'] ?></td>
                        </tr>
                    </table>
                    <hr>
                    <a href="index.php?hal=suplai_barang" class="btn btn-primary">Kembali</a>
                </div>
            </div>
        </div>
    </div>
</section>