<?php
error_reporting(0);
$status = $_SESSION['status'];
    if($status != "login"){
        header('location:index.php?hal=home');
    }

$idedit = $_REQUEST['id'];
if(!empty($idedit)){
    $modal = new Supplier();
    $row = $modal->getSupplier($idedit);
}else{
    $row = [];
}
?>


<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">Form Supplier</div>
                    <form method="POST" action="SupplierController.php" id="contactForm" data-sb-form-api-token="API_TOKEN">
                        <div class="form-floating mb-3">
                            <input class="form-control" name="nama" value="<?= $row['nama']?>" id="nama" type="text" placeholder="Nama" data-sb-validations="required" />
                            <label for="nama">Nama</label>
                            <div class="invalid-feedback" data-sb-feedback="nama:required">Nama is required.</div>
                        </div>
                        <div class="form-floating mb-3">
                            <input class="form-control" name="telepon" value="<?= $row['telp']?>" id="telepon" type="text" placeholder="Telepon" data-sb-validations="required" />
                            <label for="telepon">Telepon</label>
                            <div class="invalid-feedback" data-sb-feedback="telepon:required">Telepon is required.</div>
                        </div>
                        <div class="form-floating mb-3">
                            <input class="form-control" name="email" value="<?= $row['email']?>" id="email" type="text" placeholder="Email" data-sb-validations="required" />
                            <label for="email">Email</label>
                            <div class="invalid-feedback" data-sb-feedback="email:required">Email is required.</div>
                        </div>
                        <div class="form-floating mb-3">
                            <textarea class="form-control" name="alamat" id="alamat" rows="10" placeholder="alamat" data-sb-validations="required" style="height: 150px"><?= $row['alamat']?></textarea>
                            <label for="alamat">Alamat</label>
                            <div class="invalid-feedback" data-sb-feedback="alamat:required">Alamat is required.</div>
                        </div>
                    
                        <?php if(empty($idedit)){ ?>
                            <button class="btn btn-primary" name="proses" value="simpan" id="simpan" type="submit">Simpan</button>
                        <?php }else{ ?>
                            <button class="btn btn-warning" name="proses" value="ubah" id="ubah" type="submit">Ubah</button>
                            <input hidden name="idedit" value="<?= $idedit ?>" />
                            <?php } ?>
                        <button class="btn btn-info" name="proses" value="batal" id="batal" type="submit">Batal</button>
                        
                    </form>

                </div>
            </div>
        </div>
    </div>
</section>
            
            
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>