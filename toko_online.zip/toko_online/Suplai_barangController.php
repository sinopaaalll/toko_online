<?php
// Deklarasi file2 terkait
require_once 'koneksi.php'; 
require_once 'models/Suplai_barang.php';

// Request
$kode = $_POST['kode'];
$supplier_id = $_POST['supplier'];
$produk_id = $_POST['produk'];
$tgl = $_POST['tgl'];
$jumlah = $_POST['jumlah'];
$ket = $_POST['ket'];

// array request
$data = [$kode,$tgl,$supplier_id,$produk_id,$jumlah,$ket];


// CRUD
$button = $_POST['proses'];
$model = new Suplai_barang();
switch ($button) {
    case 'simpan': $model->simpan($data); break;
    case 'ubah': 
            $data[] = $_POST['idedit'];
            $model->ubah($data); 
        break;
    case 'hapus':
            unset($data);
            $data = array($_POST['idx']);
            $model->hapus($data);
        break;
    default: header('location:index.php?hal=suplai_barang');
}
header('location:index.php?hal=suplai_barang');

?>