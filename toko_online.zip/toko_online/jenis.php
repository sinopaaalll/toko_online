<?php
    $status = $_SESSION['status'];
    if($status != "login"){
        header('location:index.php?hal=home');
    }
    
    $objJenis = new Jenis();
    $rs = $objJenis->index(); 
?>
<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="card-title">Daftar Jenis Produk</div>
                    <a href="index.php?hal=jenis_form" class="btn btn-sm btn-primary">
                        <i class="bi bi-plus-circle-fill"></i> Tambah
                    </a>
                </div>
                    <table class="table table-striped datatable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Jenis Produk</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = 1;
                                foreach ($rs as $data) : ?>
                                    <tr>
                                        <th><?= $no?></th>
                                        <td><?= $data['nama']?></td>
                                        <td>
                                            <form action="JenisController.php" method="POST">
                                                <a class="btn btn-sm btn-warning" href="index.php?hal=jenis_form&id=<?= $data['id']?>" title="ubah">
                                                    <i class="bi bi-pencil-fill"></i>
                                                </a>
                                                <?php if ($_SESSION['role'] != 'staff') { ?>
                                                    
                                                    <button type="submit" class="btn btn-sm btn-danger" name="proses" value="hapus" onclick="return confirm('Anda Yakin Data dihapus')" title="hapus">
                                                        <i class="bi bi-trash-fill"></i>
                                                    </button>
                                                    <input type="hidden" name="idx" value="<?= $data['id']?>">
                                                <?php } ?>
                                            </form>
                                        </td>
                                    </tr>
                            <?php $no++; endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>