<?php
    $status = $_SESSION['status'];
    if($status != "login"){
        header('location:index.php?hal=home');
    }

    $objPelanggan = new Pelanggan();
    $rs = $objPelanggan->index(); 
?>
<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="card-title">Daftar Pelanggan</div>
                    <a href="index.php?hal=pelanggan_form" class="btn btn-sm btn-primary">
                        <i class="bi bi-plus-circle-fill"></i> Tambah
                    </a>
                </div>
                    <table class="table table-striped datatable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama Pelanggan</th>
                                <th>Telepon</th>
                                <th>Email</th>
                                <th>Foto</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = 1;
                                foreach ($rs as $data) : ?>
                                    <tr>
                                        <th><?= $no?></th>
                                        <td><?= $data['nama']?></td>
                                        <td><?= $data['handphone']?></td>
                                        <td><?= $data['email']?></td>
                                        <td>
                                            <img src="assets/img/<?= $data['foto']?>" style="width:75px;border-radius:10px">
                                        </td>
                                        <td>
                                            <form action="PelangganController.php" method="POST">
                                                <a class="btn btn-sm btn-info" href="index.php?hal=pelanggan_detail&id=<?= $data['id']?>" title="detail">
                                                    <i class="bi bi-eye-fill"></i>
                                                </a>
                                                <a class="btn btn-sm btn-warning" href="index.php?hal=pelanggan_form&id=<?= $data['id']?>" title="ubah">
                                                    <i class="bi bi-pencil-fill"></i>
                                                </a>
                                                <?php if ($_SESSION['role'] != 'staff') { ?>
                                                    
                                                    <button type="submit" class="btn btn-sm btn-danger" name="proses" value="hapus" onclick="return confirm('Anda Yakin Data dihapus')" title="hapus">
                                                        <i class="bi bi-trash-fill"></i>
                                                    </button>
                                                    <input type="hidden" name="idx" value="<?= $data['id']?>">
                                                <?php } ?>
                                            </form>
                                        </td>
                                    </tr>
                            <?php $no++; endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>