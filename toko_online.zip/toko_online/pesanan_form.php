<?php
error_reporting(0);
$status = $_SESSION['status'];
    if($status != "login"){
        header('location:index.php?hal=home');
    }

$idedit = $_REQUEST['id'];
if(!empty($idedit)){
    $modal = new Pesanan();
    $row = $modal->getPesanan($idedit);
}else{
    $row = [];
}
?>


<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <div class="card-title">Form Pesanan</div>
                    <form method="POST" action="PesananController.php" id="contactForm" data-sb-form-api-token="API_TOKEN">
                        <div class="form-floating mb-3">
                            <input class="form-control" name="kode" value="<?= $row['kode']?>" id="kodePesanan" type="text" placeholder="Kode Pesanan" data-sb-validations="required" />
                            <label for="kodePesanan">Kode Pesanan</label>
                            <div class="invalid-feedback" data-sb-feedback="kodePesanan:required">Kode Pesanan is required.</div>
                        </div>
                        <div class="form-floating mb-3">
                            <input class="form-control" name="tgl" value="<?= $row['tgl']?>" id="tanggalPesanan" type="date" placeholder="tanggal Pesanan" data-sb-validations="required" />
                            <label for="tanggalPesanan">Tanggal Pesanan</label>
                            <div class="invalid-feedback" data-sb-feedback="tanggalPesanan:required">tanggal Pesanan is required.</div>
                        </div>
                        <div class="form-floating mb-3">
                            <select name="pelanggan" id="Pelanggan" data-sb-validations="required" class="form-select">
                                <option value="" disabled selected> -- Pilih --</option>
                            <?php
                                $objPelanggan = new Pelanggan();
                                $rs = $objPelanggan->index();
                                foreach ($rs as $pl) { 
                                    $cek = ($pl['id'] == $row['pelanggan_id']) ? 'selected' : '';
                                ?>	
                                <option value="<?= $pl['id']?>" <?= $cek ?> ><?= $pl['nama'] ?></option>
                            <?php } ?>
                            </select>
                            <label for="Pelanggan">Pelanggan</label>
                            <div class="invalid-feedback" data-sb-feedback="Pelanggan:required">Pelanggan is required.</div>
                        </div>
                        <div class="form-floating mb-3">
                            <select name="produk" id="Produk" data-sb-validations="required" class="form-select">
                            <option value="" disabled selected> -- Pilih --</option>
                                <?php
                                    $objProduk = new Produk();
                                    $data = $objProduk->index();

                                    foreach ($data as $pk) { 
                                        $cek = ($pk['id'] == $row['produk_id']) ? 'selected' : ''; 
                                    ?>
                                    <option value="<?= $pk['id']?>" <?= $cek ?> ><?= $pk['nama'] ?></option>
                                    <?php } ?>
                            </select>
                            <label for="Produk">Produk</label>
                            <div class="invalid-feedback" data-sb-feedback="Produk:required">Produk is required.</div>
                        </div>
                        <div class="form-floating mb-3">
                            <input class="form-control" name="jumlah" value="<?= $row['jumlah']?>" id="jumlahPesanan" type="number" placeholder="jumlah Pesanan" data-sb-validations="required" />
                            <label for="jumlahPesanan">Jumlah Pesanan</label>
                            <div class="invalid-feedback" data-sb-feedback="jumlahPesanan:required">jumlah Pesanan is required.</div>
                        </div>
                        <div class="form-floating mb-3">
                            <textarea class="form-control" name="ket" id="keterangan" rows="10" placeholder="Keterangan" data-sb-validations="required" style="height: 150px"><?= $row['keterangan']?></textarea>
                            <label for="keterangan">Keterangan</label>
                            <div class="invalid-feedback" data-sb-feedback="keterangan:required">keterangan is required.</div>
                        </div>

                        
                    
                        <?php if(empty($idedit)){ ?>
                            <button class="btn btn-primary" name="proses" value="simpan" id="simpan" type="submit">Simpan</button>
                        <?php }else{ ?>
                            <button class="btn btn-warning" name="proses" value="ubah" id="ubah" type="submit">Ubah</button>
                            <input type="hidden" name="idedit" value="<?= $idedit ?>" />
                            <?php } ?>
                        <button class="btn btn-info" name="proses" value="batal" id="batal" type="submit">Batal</button>
                        
                    </form>

                </div>
            </div>
        </div>
    </div>
</section>
            
            
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>