<?php
// Deklarasi file2 terkait
require_once 'koneksi.php'; 
require_once 'models/Pelanggan.php';

// Request
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$handphone = $_POST['telepon'];
$email = $_POST['email'];
$foto = $_POST['foto'];

// array request
$data = [$nama,$alamat,$handphone,$email,$foto];

// CRUD
$button = $_POST['proses'];
$model = new Pelanggan();
switch ($button) {
    case 'simpan': $model->simpan($data); break;
    case 'ubah': 
            $data[] = $_POST['idedit'];
            $model->ubah($data); 
        break;
    case 'hapus':
            unset($data);
            $data = array($_POST['idx']);
            $model->hapus($data);
        break;
    default: header('location:index.php?hal=pelanggan');
}
header('location:index.php?hal=pelanggan');

?>