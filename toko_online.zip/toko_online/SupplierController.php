<?php
// Deklarasi file2 terkait
require_once 'koneksi.php'; 
require_once 'models/Supplier.php';

// Request
$nama = $_POST['nama'];
$alamat = $_POST['alamat'];
$handphone = $_POST['telepon'];
$email = $_POST['email'];

// array request
$data = [$nama,$alamat,$handphone,$email];

// CRUD
$button = $_POST['proses'];
$model = new Supplier();
switch ($button) {
    case 'simpan': $model->simpan($data); break;
    case 'ubah': 
            $data[] = $_POST['idedit'];
            $model->ubah($data); 
        break;
    case 'hapus':
            unset($data);
            $data = array($_POST['idx']);
            $model->hapus($data);
        break;
    default: header('location:index.php?hal=supplier');
}
header('location:index.php?hal=supplier');

?>