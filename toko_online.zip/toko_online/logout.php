<?php
session_start();
//session_destroy();
session_destroy();
//landing page

// header('location:index.php?hal=home');

// redirect with alert
echo "<script>
        window.alert('Anda sudah Logout!');
        window.location.href='index.php?hal=home';
    </script>";


?>
