<?php
class Pesanan{
    private $koneksi;

    public function __construct()
    {
        global $conn;
        $this->koneksi = $conn;
    }

    public function index()
    {
        $sql = "SELECT pesanan.*, pelanggan.nama AS pelanggan, produk.nama AS produk
                FROM pesanan
                INNER JOIN pelanggan 
                ON pelanggan.id = pesanan.pelanggan_id
                INNER JOIN produk 
                ON produk.id = pesanan.produk_id ORDER BY pesanan.id DESC";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute();
        $result = $prepareStatement->fetchAll();
        return $result;
    }

    public function getPesanan($id)
    {
        $sql = "SELECT pesanan.*, 
        pelanggan.nama AS pelanggan, pelanggan.alamat AS alamat, pelanggan.handphone AS telp,
        produk.nama AS produk, produk.harga AS harga, produk.foto AS foto
        FROM pesanan
        INNER JOIN pelanggan 
        ON pelanggan.id = pesanan.pelanggan_id
        INNER JOIN produk 
        ON produk.id = pesanan.produk_id
        WHERE pesanan.id = ?";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute([$id]);
        $result = $prepareStatement->fetch();
        return $result;
    }

    public function simpan($data)
    {
        $sql = "INSERT INTO pesanan (kode,pelanggan_id,produk_id,tgl,jumlah,keterangan) VALUES
                (?,?,?,?,?,?)";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
    }

    public function ubah($data)
    {
        $sql = "UPDATE pesanan SET kode=?, pelanggan_id=?, produk_id=?, tgl=?, jumlah=?, keterangan=? WHERE id=?";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
    }

    public function hapus($data)
    {
        $sql = "DELETE FROM pesanan WHERE id=?";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
    }
}

?>