<?php
class Supplier{
    private $koneksi;

    public function __construct()
    {
        global $conn;
        $this->koneksi = $conn;
    }

    public function index()
    {
        $sql = "SELECT * FROM supplier ORDER BY id DESC";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute();
        $result = $prepareStatement->fetchAll();
        return $result;
    }

    public function getSupplier($id)
    {
        $sql = "SELECT * FROM supplier WHERE id = ?";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute([$id]);
        $result = $prepareStatement->fetch();
        return $result;
    }

    public function simpan($data)
    {
        $sql = "INSERT INTO supplier (nama,alamat,telp,email) VALUES
                (?,?,?,?)";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
    }

    public function ubah($data)
    {
        $sql = "UPDATE supplier SET nama=?, alamat=?, telp=?, email=? WHERE id=?";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
    }

    public function hapus($data)
    {
        $sql = "DELETE FROM supplier WHERE id=?";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
    }

}

?>