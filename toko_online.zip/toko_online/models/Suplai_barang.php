<?php
class Suplai_barang{
    private $koneksi;

    public function __construct()
    {
        global $conn;
        $this->koneksi = $conn;
    }

    public function index()
    {
        $sql = "SELECT suplai_barang.*, supplier.nama AS supplier, produk.nama AS produk
                FROM suplai_barang
                INNER JOIN supplier ON supplier.id = suplai_barang.supplier_id
                INNER JOIN produk ON produk.id = suplai_barang.produk_id";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute();
        $result = $prepareStatement->fetchAll();
        return $result;
    }

    public function getSuplai_barang($id)
    {
        $sql = "SELECT suplai_barang.*, supplier.nama AS supplier, produk.nama AS produk
                FROM suplai_barang
                INNER JOIN supplier ON supplier.id = suplai_barang.supplier_id
                INNER JOIN produk ON produk.id = suplai_barang.produk_id
                WHERE suplai_barang.id = ?";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute([$id]);
        $result = $prepareStatement->fetch();
        return $result;
    }

    public function simpan($data)
    {
        $sql = "INSERT INTO suplai_barang (kode,tgl,supplier_id,produk_id,jumlah,keterangan) VALUES
                (?,?,?,?,?,?)";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
    }

    public function ubah($data)
    {
        $sql = "UPDATE suplai_barang SET kode=?, tgl=?, supplier_id=?, produk_id=?, jumlah=?, keterangan=? WHERE id=?";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
    }

    public function hapus($data)
    {
        $sql = "DELETE FROM suplai_barang WHERE id=?";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
    }
}

?>