<?php
class Member{
    private $koneksi;

    public function __construct()
    {
        global $conn;
        $this->koneksi = $conn;
    }

    public function cek_login($data)
    {
        $sql = "SELECT * FROM member WHERE email = ? AND password = (SHA1(MD5(?)))";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
        $result = $prepareStatement->fetch();
        return $result;
    }


}

?>