<?php
class Pelanggan{
    private $koneksi;

    public function __construct()
    {
        global $conn;
        $this->koneksi = $conn;
    }

    public function index()
    {
        $sql = "SELECT * FROM pelanggan ORDER BY id DESC";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute();
        $result = $prepareStatement->fetchAll();
        return $result;
    }

    public function getPelanggan($id)
    {
        $sql = "SELECT * FROM pelanggan WHERE id = ?";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute([$id]);
        $result = $prepareStatement->fetch();
        return $result;
    }

    public function simpan($data)
    {
        $sql = "INSERT INTO pelanggan (nama,alamat,handphone,email,foto) VALUES
                (?,?,?,?,?)";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
    }

    public function ubah($data)
    {
        $sql = "UPDATE pelanggan SET nama=?, alamat=?, handphone=?, email=?, foto=? WHERE id=?";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
    }

    public function hapus($data)
    {
        $sql = "DELETE FROM pelanggan WHERE id=?";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
    }

}

?>