<?php
class Produk{
    private $koneksi;

    public function __construct()
    {
        global $conn;
        $this->koneksi = $conn;
    }

    public function index()
    {
        $sql = "SELECT produk.*, jenis.nama AS kategori 
                FROM produk 
                INNER JOIN jenis 
                ON jenis.id = produk.jenis_id ORDER BY produk.id DESC";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute();
        $result = $prepareStatement->fetchAll();
        return $result;
    }

    public function getProduk($id)
    {
        $sql = "SELECT produk.*, jenis.nama AS kategori 
                FROM produk 
                INNER JOIN jenis 
                ON jenis.id = produk.jenis_id
                WHERE produk.id = ?";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute([$id]);
        $result = $prepareStatement->fetch();
        return $result;
    }

    public function simpan($data)
    {
        $sql = "INSERT INTO produk (kode,nama,jenis_id,harga,stok,foto) VALUES
                (?,?,?,?,?,?)";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
    }

    public function ubah($data)
    {
        $sql = "UPDATE produk SET kode=?, nama=?, jenis_id=?, harga=?, stok=?, foto=? WHERE id=?";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
    }

    public function hapus($data)
    {
        $sql = "DELETE FROM produk WHERE id=?";
        // Prepare Statement PDO
        $prepareStatement = $this->koneksi->prepare($sql);
        $prepareStatement->execute($data);
    }
}

?>