<?php
// Deklarasi file2 terkait
require_once 'koneksi.php'; 
require_once 'models/Pesanan.php';

// Request
$kode = $_POST['kode'];
$pelanggan_id = $_POST['pelanggan'];
$produk_id = $_POST['produk'];
$tgl = $_POST['tgl'];
$jumlah = $_POST['jumlah'];
$ket = $_POST['ket'];

// array request
$data = [$kode,$pelanggan_id,$produk_id,$tgl,$jumlah,$ket];

// CRUD
$button = $_POST['proses'];
$model = new Pesanan();
switch ($button) {
    case 'simpan': $model->simpan($data); break;
    case 'ubah': 
            $data[] = $_POST['idedit'];
            $model->ubah($data); 
        break;
    case 'hapus':
            unset($data);
            $data = array($_POST['idx']);
            $model->hapus($data);
        break;
    default: header('location:index.php?hal=pesanan');
}
header('location:index.php?hal=pesanan');

?>