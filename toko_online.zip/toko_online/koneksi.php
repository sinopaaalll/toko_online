<?php   
$dbname = 'toko_online';
$dsn = 'mysql:dbname='.$dbname.'; host=localhost';
$user = 'root'; $password = '';

try{
    // $conn = koneksi
    $conn = new PDO($dsn, $user, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);
    // print "Koneksi sukses";
} catch(PDOException $e) {
    print "Terjadi kesalahan" . $e->getMessage();
}

?>