<?php
    $status = $_SESSION['status'];
    if($status != "login"){
        header('location:index.php?hal=home');
    }

    $id = $_REQUEST['id'];
    $objPelanggan = new Pelanggan();
    $rs = $objPelanggan->getPelanggan($id);  
?>
<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="row row-cols-1 row-cols-md-3 g-4">
                <div class="col">
                    <div class="card">
                    <img src="assets/img/<?= $rs['foto'];?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title"><?= $rs['nama'];?></h5>
                            <table>
                                <tr>
                                    <td>Telepon</td>
                                    <td>: </td>
                                    <td><?= $rs['handphone'];?></td>
                                </tr>
                                <tr>
                                    <td>Email</td>
                                    <td>: </td>
                                    <td><?= $rs['email'];?></td>
                                </tr>
                                <tr>
                                    <td>Alamat</td>
                                    <td>: </td>
                                    <td><?= $rs['alamat'];?></td>
                                </tr>
                            </table>
                            <hr>
                            <a href="index.php?hal=pelanggan" class="btn btn-primary">Go Back</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>