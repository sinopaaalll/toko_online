<?php
// Deklarasi file2 terkait
require_once 'koneksi.php'; 
require_once 'models/Produk.php';

// Request
$kode = $_POST['kode'];
$nama = $_POST['nama'];
$jenis_id = $_POST['jenis'];
$harga = $_POST['harga'];
$stok = $_POST['stok'];
$foto = $_POST['foto'];

// array request
$data = [$kode,$nama,$jenis_id,$harga,$stok,$foto];

// CRUD
$button = $_POST['proses'];
$model = new Produk();
switch ($button) {
    case 'simpan': $model->simpan($data); break;
    case 'ubah': 
            $data[] = $_POST['idedit'];
            $model->ubah($data); 
        break;
    case 'hapus':
            unset($data);
            $data = array($_POST['idx']);
            $model->hapus($data);
        break;
    default: header('location:index.php?hal=produk');
}
header('location:index.php?hal=produk');

?>