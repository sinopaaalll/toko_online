<?php
    $status = $_SESSION['status'];
    if($status != "login"){
        header('location:index.php?hal=home');
    }

    $objSuplai_barang = new Suplai_barang();
    $rs = $objSuplai_barang->index();
?>
<section class="section">
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="card-title">Daftar Suplai Barang</div>
                    <a href="index.php?hal=suplai_barang_form" class="btn btn-sm btn-primary">
                        <i class="bi bi-plus-circle-fill"></i> Tambah
                    </a>
                </div>
                    <table class="table table-striped datatable">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Kode</th>
                                <th>Tanggal</th>
                                <th>Supplier</th>
                                <th>Produk</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = 1;
                                foreach ($rs as $data) : ?>
                                    <tr>
                                        <th><?= $no?></th>
                                        <td><?= $data['kode']?></td>
                                        <td><?= date('d M Y',strtotime($data['tgl']))?></td>
                                        <td><?= $data['supplier']?></td>
                                        <td><?= $data['produk']?></td>
                                        <td>
                                            <form action="Suplai_barangController.php" method="POST">
                                                <a class="btn btn-sm btn-info" href="index.php?hal=suplai_barang_detail&id=<?= $data['id']?>" title="detail">
                                                    <i class="bi bi-eye-fill"></i>
                                                </a>
                                                <?php
                                                if($_SESSION['role'] != 'staff'){ ?>
                                                <a class="btn btn-sm btn-warning" href="index.php?hal=suplai_barang_form&id=<?= $data['id']?>" title="ubah">
                                                    <i class="bi bi-pencil-fill"></i>
                                                </a>
                                                <button type="submit" class="btn btn-sm btn-danger" name="proses" value="hapus" onclick="return confirm('Anda Yakin Data dihapus')" title="hapus">
                                                    <i class="bi bi-trash-fill"></i>
                                                </button>
                                                <input type="hidden" name="idx" value="<?= $data['id']?>">
                                                <?php } ?>
                                            </form>
                                        </td>
                                    </tr>
                            <?php $no++; endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</section>