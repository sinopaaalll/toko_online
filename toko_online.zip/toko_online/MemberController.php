<?php
session_start();

// Deklarasi file2 terkait
require_once 'koneksi.php'; 
require_once 'models/Member.php';

// Request
$email = $_POST['email'];
$pass = $_POST['password'];

// array request
$data = [$email,$pass];

// CRUD
$button = $_POST['proses'];
$model = new Member();
$result = $model->cek_login($data);

if (!empty($result)) {
    $_SESSION['fullname'] = $result['fullname'];
    $_SESSION['role'] = $result['role'];
    $_SESSION['foto'] = $result['foto'];
    $_SESSION['status'] = "login";
    header('location:index.php?hal=produk');
}else{
    echo "<script>
            alert('Maaf Email/Password anda salah!');
            history.back();
        </script>";
}


// switch ($button) {
//     case 'simpan': $model->simpan($data); break;
//     case 'ubah': 
//             $data[] = $_POST['idedit'];
//             $model->ubah($data); 
//         break;
//     case 'hapus':
//             unset($data);
//             $data = array($_POST['idx']);
//             $model->hapus($data);
//         break;
//     default: header('location:index.php?hal=produk');
// }
// header('location:index.php?hal=produk');

?>