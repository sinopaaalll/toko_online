<?php
// Deklarasi file2 terkait
require_once 'koneksi.php'; 
require_once 'models/Jenis.php';

// Request
$nama = $_POST['nama'];

// array request
$data = [$nama];

// CRUD
$button = $_POST['proses'];
$model = new Jenis();
switch ($button) {
    case 'simpan': $model->simpan($data); break;
    case 'ubah': 
            $data[] = $_POST['idedit'];
            $model->ubah($data); 
        break;
    case 'hapus':
            unset($data);
            $data = array($_POST['idx']);
            $model->hapus($data);
        break;
    default: header('location:index.php?hal=jenis');
}
header('location:index.php?hal=jenis');

?>